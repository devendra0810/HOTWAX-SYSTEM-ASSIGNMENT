package com.example.HOTWAXASSIGNMENT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotwaxassignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
