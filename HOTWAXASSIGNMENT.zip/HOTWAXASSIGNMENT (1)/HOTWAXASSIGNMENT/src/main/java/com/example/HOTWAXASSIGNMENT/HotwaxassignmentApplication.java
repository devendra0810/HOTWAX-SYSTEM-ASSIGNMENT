package com.example.HOTWAXASSIGNMENT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotwaxassignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotwaxassignmentApplication.class, args);
	}

}
